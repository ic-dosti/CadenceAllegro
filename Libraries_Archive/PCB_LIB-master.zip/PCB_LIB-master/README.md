PCB_LIB
=========

PCB footprint library by Tao-Yi Lee tylee@ieee.org

Please read "LICENSE"